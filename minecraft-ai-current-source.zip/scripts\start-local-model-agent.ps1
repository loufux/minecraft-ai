﻿[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)]
    [ValidateSet('Qwen3','Gemma','DeepSeek')]
    [string]$AgentName,
    [string]$Mode = '',
    [string]$PlayerName = 'loufux'
)

$ErrorActionPreference = 'Stop'
Set-Location (Split-Path -Parent $PSScriptRoot)
. (Join-Path $PSScriptRoot 'agent-mode.ps1')
$modeConfig = Get-AgentModeConfig -RequestedMode $Mode -PlayerName $PlayerName
if ($null -eq $modeConfig) { Write-Host 'Запуск отменён.' -ForegroundColor DarkGray; exit 0 }

$configPath = Join-Path (Get-Location) 'config\lmstudio-team.json'
if (-not (Test-Path -LiteralPath $configPath)) {
    throw 'config/lmstudio-team.json not found. Run setup-lmstudio-minecraft-team.py first.'
}
$config = Get-Content -LiteralPath $configPath -Raw -Encoding UTF8 | ConvertFrom-Json
$spec = $config.agents.$AgentName
if (-not $spec -or -not $spec.model) { throw "No LM Studio model configured for $AgentName." }

Write-Host "[$AgentName] Ensuring LM Studio models are loaded..." -ForegroundColor Cyan
$manager = Join-Path $PSScriptRoot 'lmstudio_manager.py'
$pyLauncher = Get-Command 'py.exe' -ErrorAction SilentlyContinue
if ($pyLauncher) { & $pyLauncher.Source -3.14 $manager 'ensure' }
else { & python $manager 'ensure' }
if ($LASTEXITCODE -ne 0) { throw 'LM Studio did not become ready. Check LM Studio and run python scripts/lmstudio_manager.py ensure.' }

# The manager resolves the OpenAI-compatible model IDs; reload its updated config.
$config = Get-Content -LiteralPath $configPath -Raw -Encoding UTF8 | ConvertFrom-Json
$spec = $config.agents.$AgentName
if (-not $spec -or -not $spec.model) { throw "LM Studio did not resolve a model ID for $AgentName." }

$env:MINECRAFT_LMSTUDIO = '1'
Remove-Item Env:MINECRAFT_CODEX,Env:MINECRAFT_CLAUDE,Env:MINECRAFT_DEEPSEEK -ErrorAction SilentlyContinue
$env:MODEL_BASE_URL = [string]$config.baseUrl
$env:AGENT_SCENARIO = [string]$modeConfig.Scenario
$env:AGENT_STATE_DIR = [string]$modeConfig.StateDir
$env:MINECRAFT_OBJECTIVE = [string]$modeConfig.Objective
$env:MINECRAFT_OPERATOR = $PlayerName

$agentArgs = @(
    'bin/minecraft-agent.js',
    '--name', $AgentName,
    '--host', '127.0.0.1',
    '--model', ('lmstudio/' + [string]$spec.model),
    '--base-url', [string]$config.baseUrl,
    '--sandbox', 'none',
    '--scenario', [string]$modeConfig.Scenario,
    '--team',
    '--peers', 'Qwen3,Gemma,DeepSeek',
    '--state-dir', [string]$modeConfig.StateDir,
    '--objective', [string]$modeConfig.Objective
)
Write-Host "[$AgentName] Local model: $($spec.model)" -ForegroundColor Green
& node @agentArgs
exit $LASTEXITCODE
