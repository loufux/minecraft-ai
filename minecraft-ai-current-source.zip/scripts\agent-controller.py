from pathlib import Path
import json, msvcrt, os, re, subprocess, sys, time
ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / 'scripts'))
from lmstudio_manager import ensure_models_loaded, read_config as read_lmstudio_config
SCENARIO = os.environ.get('AGENT_SCENARIO', 'vanilla').strip().lower()
if SCENARIO not in ('vanilla', 'skyblock'):
    raise SystemExit(f'Invalid AGENT_SCENARIO {SCENARIO!r}; expected vanilla or skyblock.')
SERVER_DEFAULT = 'vanilla-server' if SCENARIO == 'vanilla' else 'skyblock-server'
SERVER = ROOT / os.environ.get('MINECRAFT_SERVER_DIR', SERVER_DEFAULT)
LOG = SERVER / 'live-console.log'
CONTROL = SERVER / 'console-commands.txt'
OUT = ROOT / 'agent-logs' if SCENARIO == 'skyblock' else ROOT / 'agent-logs' / 'vanilla'
DEFAULT_OBJECTIVES = {
    'vanilla': 'Cooperate as one team in ordinary Minecraft Java survival. Start from the naturally generated Overworld spawn, gather resources, build a safe base, progress through the Nether, find a stronghold, enter the End and defeat the Ender Dragon. Verify important discoveries and the final victory in the actual world.',
    'skyblock': 'Cooperate with Qwen3, Gemma and DeepSeek in Skyblock. Together put 1 diamond in the starter chest at (-2,65,-4). Mine cobblestone from the existing generator, reach the sand island, build a house and reach the Nether along the way.',
}
OBJ = os.environ.get('MINECRAFT_OBJECTIVE', DEFAULT_OBJECTIVES[SCENARIO])
STATE_DEFAULT = '.agent-state-vanilla' if SCENARIO == 'vanilla' else '.agent-state'
STATE_DIR = os.environ.get('AGENT_STATE_DIR', STATE_DEFAULT)
SPECS = {'Qwen3': ('MINECRAFT_CODEX','openai/gpt-6-luna'), 'Gemma': ('MINECRAFT_CLAUDE','anthropic/claude-haiku-5-5'), 'DeepSeek': ('MINECRAFT_DEEPSEEK','deepseek/deepseek-flash')}
PLAYER = os.environ.get('MINECRAFT_OPERATOR', os.environ.get('SKYBLOCK_PLAYER', 'loufux'))
workers = {}

def announce(msg):
    with CONTROL.open('a', encoding='utf-8') as f:
        f.write('tellraw @a ' + json.dumps({'text':msg,'color':'aqua'}, ensure_ascii=False) + '\n')

def start():
    local_config_path = ROOT / 'config' / 'lmstudio-team.json'
    local_cfg = None
    if local_config_path.exists():
        try:
            local_cfg = read_lmstudio_config()
        except Exception as exc:
            announce('Не удалось прочитать config/lmstudio-team.json: ' + str(exc)[:180])
            return False
        ready, reason = ensure_models_loaded(local_cfg, verbose=False)
        if not ready:
            announce('LM Studio пока не готов: ' + str(reason)[:220] + '. Открой LM Studio; контроллер повторит запуск автоматически.')
            with (OUT / 'lmstudio-errors.log').open('a', encoding='utf-8') as log:
                log.write(time.strftime('%Y-%m-%d %H:%M:%S') + ' ' + str(reason) + '\n')
            return False
        specs = [(name, str(spec['model'])) for name, spec in local_cfg['agents'].items()]
    else:
        specs = [(name, model) for name, (_flag, model) in SPECS.items()]

    names = []
    for name, model in specs:
        if name in workers and workers[name].poll() is None:
            continue
        env = os.environ.copy()
        for key in ('MINECRAFT_CODEX', 'MINECRAFT_CLAUDE', 'MINECRAFT_DEEPSEEK', 'MINECRAFT_LMSTUDIO'):
            env.pop(key, None)
        if local_cfg:
            env['MINECRAFT_LMSTUDIO'] = '1'
            env['MODEL_BASE_URL'] = str(local_cfg.get('baseUrl', 'http://127.0.0.1:1234/v1'))
            env.pop('DEEPSEEK_API_KEY', None)
            args = ['node', 'bin/minecraft-agent.js', '--name', name, '--host', '127.0.0.1',
                    '--model', 'lmstudio/' + model, '--base-url', env['MODEL_BASE_URL'],
                    '--sandbox', 'none', '--scenario', SCENARIO, '--state-dir', STATE_DIR,
                    '--team', '--peers', 'Qwen3,Gemma,DeepSeek', '--objective', OBJ]
        else:
            flag, _legacy_model = SPECS[name]
            env[flag] = '1'
            thinking = ['--thinking', 'high'] if name == 'Gemma' else []
            args = ['node', 'bin/minecraft-agent.js', '--name', name, '--host', '127.0.0.1', '--model', model, *thinking,
                    '--sandbox', 'none', '--scenario', SCENARIO, '--state-dir', STATE_DIR,
                    '--team', '--peers', 'Qwen3,Gemma,DeepSeek', '--objective', OBJ]
        with (OUT / (name + '.log')).open('ab', buffering=0) as log:
            workers[name] = subprocess.Popen(args, cwd=ROOT, env=env, stdin=subprocess.DEVNULL,
                                              stdout=log, stderr=subprocess.STDOUT,
                                              creationflags=subprocess.CREATE_NO_WINDOW)
        names.append(name)
    if local_cfg:
        announce('Запускаю локальную команду LM Studio: ' + ', '.join(names) if names else 'Локальные агенты уже запущены.')
    else:
        announce('Запускаю агентов: ' + ', '.join(names) if names else 'Агенты уже запущены.')
    return True

def remove():
    for name,p in list(workers.items()):
        if p.poll() is None:
            subprocess.run(['taskkill','/PID',str(p.pid),'/T','/F'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,creationflags=subprocess.CREATE_NO_WINDOW)
    announce('Агенты отключены.')

def main():
    OUT.mkdir(parents=True, exist_ok=True)
    lock=(ROOT/'scripts'/('agent-controller.lock' if SCENARIO == 'skyblock' else 'agent-controller-vanilla.lock')).open('a+b')
    try: msvcrt.locking(lock.fileno(),msvcrt.LK_NBLCK,1)
    except OSError: return
    offset=LOG.stat().st_size if LOG.exists() else 0
    if '--log-start-offset' in sys.argv:
        try:
            offset = max(0, int(sys.argv[sys.argv.index('--log-start-offset') + 1]))
        except (ValueError, IndexError):
            raise SystemExit('Invalid --log-start-offset value')
    pending=b''
    if '--start' in sys.argv: start()
    start_when_ready = '--start-when-ready' in sys.argv
    ready_seen = False
    next_start_attempt = 0.0
    while True:
        try:
            if LOG.exists():
                if LOG.stat().st_size < offset: offset=0; pending=b''
                with LOG.open('rb') as f: f.seek(offset); data=f.read(); offset=f.tell()
                lines=(pending+data).split(b'\n'); pending=lines.pop()
                for raw in lines:
                    line=raw.decode('utf-8','replace').strip()
                    line=re.sub(r'\x1b\[[0-9;]*m', '', line)
                    if start_when_ready and re.search(r'\bDone \(.*\)!', line):
                        ready_seen = True
                    m=re.search(re.escape(PLAYER) + r' issued server command: /agents (start|remove|stop)\s*$',line,re.I)
                    if m: (start if m.group(1).lower()=='start' else remove)()
            if start_when_ready and ready_seen and time.monotonic() >= next_start_attempt:
                if start():
                    start_when_ready = False
                else:
                    next_start_attempt = time.monotonic() + 10
            time.sleep(.3)
        except Exception as e:
            with (OUT/'controller-errors.log').open('a',encoding='utf-8') as f: f.write(repr(e)+'\n')
            time.sleep(1)
if __name__ == '__main__': main()
