# Локальная команда Minecraft через LM Studio

## Состав команды

| Minecraft-ник | Локальная модель | Роль |
|---|---|---|
| Qwen3 | `Qwen3-1.7B-Q4_K_M.gguf` | Командир и распределение задач |
| Gemma | `gemma-3-1b-it-Q4_K_M.gguf` | Разведчик и безопасность |
| DeepSeek | `DeepSeek-R1-Distill-Qwen-1.5B-Q3_K_M.gguf` | Стратегия и крафт |

Модели работают локально через LM Studio API: `http://127.0.0.1:1234/v1`. API-ключи OpenAI, Anthropic и DeepSeek не требуются.

## Запуск всей команды

1. Открой LM Studio и запусти Local Server на порту 1234.
2. Запусти сервер и всех агентов:

```powershell
.\start-server.ps1 -StartAgents
```

3. Выбери Vanilla или Skyblock.

## Отдельный запуск агентов

Сначала запусти Minecraft-сервер, затем в отдельных PowerShell-окнах:

```powershell
.\start-qwen3.ps1 -Mode Vanilla
.\start-gemma.ps1 -Mode Vanilla
.\start-deepseek.ps1 -Mode Vanilla
```

Есть и Python-обёртки:

```powershell
py -3.14 .\start-qwen3.py --mode Vanilla
py -3.14 .\start-gemma.py --mode Vanilla
py -3.14 .\start-deepseek.py --mode Vanilla
```

Для Skyblock замени `Vanilla` на `Skyblock`.

## Проверка LM Studio

```powershell
py -3.14 scripts\lmstudio_manager.py ensure
```

Модели хранятся в LM Studio; исходные GGUF файлы не удаляются. Настройка проекта находится в `config/lmstudio-team.json`. Резервные копии исходников — в `.lmstudio-team-backup`.

## Скины офлайн-ботов

Paper запущен с `online-mode=false`, поэтому Mineflayer-боты входят как офлайн-профили без аутентифицированных Mojang skin-текстур. Для скинов установи SkinsRestorer в оба сервера:

```powershell
py -3.14 setup-lmstudio-minecraft-team.py --skins-only
```

Останови оба сервера перед установкой/обновлением плагина и запусти их заново. Когда боты находятся онлайн, в игровом чате от имени оператора назначь им скины существующих Minecraft Java-аккаунтов:

```text
/skin set <skinAccountName> Qwen3
/skin set <skinAccountName> Gemma
/skin set <skinAccountName> DeepSeek
```

Вместо `<skinAccountName>` укажи аккаунт, с которого брать внешний вид. SkinsRestorer поддерживает Paper и offline-mode. Если у ботов уже есть сессия, переподключи их после назначения.

## Ограничение маленьких моделей

Установщик проверяет tool-calling каждой модели. Если видишь WARN, модель может отвечать текстом, но её надёжное управление игровыми инструментами не подтверждено.
