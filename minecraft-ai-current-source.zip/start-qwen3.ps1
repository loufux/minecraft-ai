﻿[CmdletBinding()]
param(
    [string]$Mode = '',
    [string]$PlayerName = 'loufux'
)

$ErrorActionPreference = 'Stop'
& (Join-Path $PSScriptRoot 'scripts\start-local-model-agent.ps1') -AgentName 'Qwen3' -Mode $Mode -PlayerName $PlayerName
exit $LASTEXITCODE
