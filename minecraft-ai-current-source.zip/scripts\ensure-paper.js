import { createHash } from 'node:crypto';
import {
    copyFileSync,
    existsSync,
    mkdirSync,
    readFileSync,
    renameSync,
    statSync,
    unlinkSync,
    writeFileSync,
} from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { getPaperBuildApiUrl, getPaperJarFilename, selectPaperBuild } from './paper-jar.js';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const args = process.argv.slice(2);
function option(name) {
    const index = args.indexOf(name);
    return index >= 0 ? args[index + 1] : undefined;
}
const version = option('--version') ?? '1.21.6';
const targetArg = option('--target');
const peerArg = option('--peer');
if (!targetArg || !peerArg) {
    console.error('Usage: node scripts/ensure-paper.js --version 1.21.6 --target <active-jar> --peer <other-mode-jar>');
    process.exit(2);
}
const target = path.resolve(root, targetArg);
const peer = path.resolve(root, peerArg);
if (target === peer) throw new Error('Target and peer Paper paths must be different.');
const expectedName = getPaperJarFilename(version);
const legacyRootJar = path.join(root, expectedName);

function isUsable(file) {
    try { return statSync(file).isFile() && statSync(file).size > 1024 * 1024; }
    catch { return false; }
}

function sha256(file) {
    return createHash('sha256').update(readFileSync(file)).digest('hex');
}

function atomicCopy(source, destination) {
    mkdirSync(path.dirname(destination), { recursive: true });
    const temporary = `${destination}.${process.pid}.part`;
    try {
        copyFileSync(source, temporary);
        if (existsSync(destination)) unlinkSync(destination);
        renameSync(temporary, destination);
    } finally {
        if (existsSync(temporary)) unlinkSync(temporary);
    }
}

async function download(destination) {
    console.log(`Neither mode folder contains ${expectedName}; downloading it into the selected mode folder.`);
    const metadataResponse = await fetch(getPaperBuildApiUrl(version), {
        headers: {
            'user-agent': 'minecraft-agent-harness/0.1.0 (+https://github.com/yc-software/minecraft-agent-harness)',
            accept: 'application/json',
        },
    });
    if (!metadataResponse.ok) throw new Error(`PaperMC metadata request failed (HTTP ${metadataResponse.status}).`);
    const metadata = await metadataResponse.json();
    const build = selectPaperBuild(metadata, version);
    const file = build?.downloads?.['server:default'];
    if (!file?.url || !file?.checksums?.sha256) throw new Error(`Paper ${version} build metadata has no server download/checksum.`);
    const response = await fetch(file.url);
    if (!response.ok) throw new Error(`Paper JAR download failed (HTTP ${response.status}).`);
    const body = Buffer.from(await response.arrayBuffer());
    const actualHash = createHash('sha256').update(body).digest('hex');
    if (actualHash !== file.checksums.sha256) throw new Error(`SHA-256 mismatch for ${file.name ?? expectedName}.`);
    mkdirSync(path.dirname(destination), { recursive: true });
    const temporary = `${destination}.${process.pid}.part`;
    writeFileSync(temporary, body);
    if (existsSync(destination)) unlinkSync(destination);
    renameSync(temporary, destination);
    console.log(`Downloaded and verified ${file.name ?? expectedName}: ${destination}`);
}

mkdirSync(path.dirname(target), { recursive: true });
mkdirSync(path.dirname(peer), { recursive: true });

// Migrate the root-level JAR used by older project versions into the selected
// mode folder. The root copy is removed after both mode-local copies agree.
if (!isUsable(target) && !isUsable(peer) && isUsable(legacyRootJar)) {
    console.log(`Moving the previous root-level Paper JAR into the selected mode folder: ${target}`);
    atomicCopy(legacyRootJar, target);
}

if (!isUsable(target)) {
    // Preserve the original per-mode startup behavior: the selected mode is
    // always the download destination when its own JAR is missing. Only after
    // the download is verified do we mirror that JAR into the other mode folder.
    // Never use the peer folder as a download fallback; the selected mode is
    // authoritative for this launch.
    await download(target);
} else {
    console.log(`Using the selected mode's existing Paper JAR: ${target}`);
}

if (!isUsable(target)) throw new Error(`Paper JAR is missing or too small after preparation: ${target}`);

const targetHash = sha256(target);
if (!isUsable(peer) || sha256(peer) !== targetHash) {
    atomicCopy(target, peer);
    if (sha256(peer) !== targetHash) throw new Error(`Could not synchronize Paper JAR into the other mode folder: ${peer}`);
    console.log(`Copied the selected mode's Paper JAR to the other mode folder: ${peer}`);
} else {
    console.log(`The other mode folder already has the same Paper JAR: ${peer}`);
}

if (isUsable(legacyRootJar)) {
    if (sha256(legacyRootJar) === targetHash) {
        unlinkSync(legacyRootJar);
        console.log('Removed the matching legacy root-level Paper JAR.');
    } else {
        const archiveDir = path.join(root, 'paper-archive');
        mkdirSync(archiveDir, { recursive: true });
        const archived = path.join(archiveDir, `${path.parse(expectedName).name}-legacy-${Date.now()}.jar`);
        renameSync(legacyRootJar, archived);
        console.warn(`The old root-level JAR differed from the selected build; preserved it at ${archived}`);
    }
}

console.log('Paper is ready. Each mode keeps its own local copy; no active JAR is stored in the project root.');
