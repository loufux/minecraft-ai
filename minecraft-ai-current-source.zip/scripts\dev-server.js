import { startupCommands } from './dev-world.js';
import { createHash } from 'node:crypto';
import { existsSync, mkdirSync, readFileSync, writeFileSync, renameSync, createWriteStream } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { getPaperBuildApiUrl, resolveServerPaperJar, selectPaperBuild } from './paper-jar.js';
import { seedMojangCache, watchMojangCache } from './paperclip-cache.js';
import { spawn, spawnSync } from 'node:child_process';
import { parseArgs } from 'node:util';

const { values } = parseArgs({
    options: {
        'mc-version': { type: 'string', default: process.env.MC_VERSION ?? '1.21.6' },
        port: { type: 'string', default: process.env.MC_PORT ?? '25565' },
        dir: { type: 'string', default: 'server' },
        memory: { type: 'string', default: '2G' },
        seed: { type: 'string', default: process.env.MC_SEED ?? '2024' },
        world: { type: 'string', default: 'normal' },
        'rcon-password': { type: 'string', default: process.env.MC_RCON_PASSWORD },
        'rcon-port': { type: 'string', default: '25575' },
        'paper-jar': { type: 'string' },
        help: { type: 'boolean', short: 'h' },
    },
});

if (values.help) {
    console.log(
        'Usage: npm run server -- [--mc-version 1.21.6] [--port 25565] [--dir server] [--memory 2G] [--seed 2024]\n' +
            '                         [--world normal|void] [--rcon-password secret] [--rcon-port 25575] [--paper-jar path]',
    );
    console.log(
        'Downloads Paper, accepts the Minecraft EULA on your behalf and starts an offline-mode server for local testing.\n' +
            'New worlds use seed 2024 (forest spawn with trees close by). Every start sets the time to morning.\n' +
            '--world void makes new worlds empty (for arenas built by a script); --rcon-password turns on RCON.',
    );
    process.exit(0);
}

if (!['normal', 'void'].includes(values.world)) {
    console.error('--world must be normal or void');
    process.exit(2);
}
const version = values['mc-version'];
const projectRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const dir = path.resolve(projectRoot, values.dir);
const peerDir = process.env.PAPER_PEER_DIR ? path.resolve(projectRoot, process.env.PAPER_PEER_DIR) : null;
const jar = resolveServerPaperJar({
    projectRoot,
    version,
    serverDir: values.dir,
    explicitPath: values['paper-jar'],
    envPath: process.env.PAPER_JAR,
});

// Fail fast before downloading Paper or writing server config when an older
// Java runtime (commonly Java 17) is still first on PATH.
const javaCommand = process.env.JAVA_EXE || 'java';
const javaVersion = spawnSync(javaCommand, ['-version'], { encoding: 'utf8', windowsHide: true });
const javaText = `${javaVersion.stdout ?? ''}\n${javaVersion.stderr ?? ''}`;
const javaMatch = javaText.match(/(?:version\s+\"?(\d+)|openjdk\s+(\d+))/i);
const javaMajor = Number(javaMatch?.[1] ?? javaMatch?.[2] ?? 0);
if (javaVersion.error || javaVersion.status !== 0 || javaMajor < 21) {
    console.error('\nPaper 1.21.6 requires Java 21 or newer.');
    console.error(javaVersion.error?.message ?? (javaText.trim() || 'Could not determine the Java runtime version.'));
    console.error('Install a 64-bit Java 21 runtime (Temurin/Corretto), then reopen PowerShell and run start-server.ps1 again.');
    process.exit(1);
}
console.log(`Using Java ${javaMajor}: ${javaCommand}`);
mkdirSync(dir, { recursive: true });
mkdirSync(path.dirname(jar), { recursive: true });

// Paperclip stores Mojang's vanilla server JAR in cache/mojang_<version>.jar.
// Reuse an existing cache from either mode, then mirror a newly downloaded cache
// from the selected mode once Paperclip has finished writing it.
if (peerDir) seedMojangCache({ selectedServerDir: dir, peerServerDir: peerDir, version });
const mojangCacheWatcher = peerDir
    ? watchMojangCache({ selectedServerDir: dir, peerServerDir: peerDir, version })
    : null;

async function download() {
    const metadataUrl = getPaperBuildApiUrl(version);
    const res = await fetch(metadataUrl, {
        headers: {
            'user-agent': 'minecraft-agent-harness/0.1.0 (+https://github.com/yc-software/minecraft-agent-harness)',
            accept: 'application/json',
        },
    });
    if (!res.ok) throw new Error(`PaperMC has no builds for ${version} (HTTP ${res.status})`);
    const buildMetadata = await res.json();
    const build = selectPaperBuild(buildMetadata, version);
    const file = build?.downloads?.['server:default'];
    if (!file) throw new Error(`No server download for Paper ${version}`);
    console.log(`Downloading ${file.name} into the selected server folder: ${jar}`);
    const downloadResponse = await fetch(file.url);
    if (!downloadResponse.ok) throw new Error(`Paper jar download failed (HTTP ${downloadResponse.status})`);
    const body = Buffer.from(await downloadResponse.arrayBuffer());
    const sha = createHash('sha256').update(body).digest('hex');
    if (sha !== file.checksums.sha256) throw new Error(`Checksum mismatch for ${file.name}`);
    const temporaryJar = `${jar}.part`;
    writeFileSync(temporaryJar, body);
    // Rename only after SHA-256 verification so a partial download is never used.
    renameSync(temporaryJar, jar);
}

if (!existsSync(jar)) await download();
writeFileSync(path.join(dir, 'eula.txt'), 'eula=true\n');
const props = path.join(dir, 'server.properties');
const defaults = {
    'spawn-protection': '0',
    difficulty: 'peaceful',
    'view-distance': '8',
    'simulation-distance': '8',
    gamemode: 'survival',
    'spawn-monsters': 'true',
    'spawn-animals': 'true',
    'generate-structures': 'true',
    motd: 'minecraft-agent-harness dev server',
    'level-seed': values.seed,
};
const worldExists = existsSync(path.join(dir, 'world', 'level.dat'));
const current = existsSync(props)
    ? Object.fromEntries(
          readFileSync(props, 'utf8')
              .split('\n')
              .filter(l => l.includes('=') && !l.startsWith('#'))
              .map(l => [l.slice(0, l.indexOf('=')), l.slice(l.indexOf('=') + 1)])
              .filter(([k, v]) => v !== '' || !(k in defaults)),
      )
    : {};
const forced = {
    difficulty: values.world === 'void' ? 'easy' : 'normal',
    'server-ip': '127.0.0.1',
    'online-mode': 'false',
    'server-port': values.port,
    ...(values.world === 'normal' ? { gamemode: 'survival', 'spawn-monsters': 'true', 'spawn-animals': 'true', 'allow-nether': 'true', 'generate-structures': 'true' } : {}),
    ...(!worldExists && values.world === 'normal'
        ? { 'level-type': 'minecraft:normal', 'generate-structures': 'true' }
        : {}),
    ...(values.world === 'void' && !worldExists
        ? {
              'level-type': 'minecraft:flat',
              'generator-settings': JSON.stringify({
                  layers: [{ block: 'minecraft:air', height: 1 }],
                  biome: 'minecraft:plains',
              }),
              'generate-structures': 'true',
          }
        : {}),
    ...(values['rcon-password']
        ? { 'enable-rcon': 'true', 'rcon.port': values['rcon-port'], 'rcon.password': values['rcon-password'] }
        : {}),
};
writeFileSync(
    props,
    Object.entries({ ...defaults, ...current, ...forced })
        .map(([k, v]) => `${k}=${v}`)
        .join('\n') + '\n',
);
console.log(`Using Paper jar in this server folder: ${jar}`);
console.log(`Starting Paper ${version} on port ${values.port} (offline mode, ${values.world} world, ${values.world === 'normal' ? 'normal difficulty' : 'easy difficulty'}). Type "stop" to shut down.`);
if (worldExists)
    console.log(`Using the existing world in ${dir}/world. Delete ${dir}/world* to generate a new one from the seed.`);
const child = spawn(javaCommand, [`-Xmx${values.memory}`, '-jar', jar, '--nogui'], {
    cwd: dir,
    stdio: ['pipe', 'pipe', 'inherit'],
});
process.stdin.pipe(child.stdin, { end: false });
const liveLog = process.env.MINECRAFT_SUPERVISOR_LOG === '1'
    ? null
    : createWriteStream(path.join(dir, 'live-console.log'), { flags: 'a' });
// Voice helpers are tied to this Paper process so they stop on server shutdown.
const voiceProcesses = [];
const voicePython = path.join(projectRoot, '.venv-voice', 'Scripts', 'python.exe');
const microphoneEnabled = existsSync(path.join(projectRoot, 'stt', 'microphone.enabled'));
function startVoiceHelper(relativeScript, label) {
    const script = path.join(projectRoot, relativeScript);
    if (!existsSync(script)) return;
    const helper = spawn(voicePython, [script, '--parent', String(process.pid)], {
        cwd: projectRoot,
        stdio: 'ignore',
        windowsHide: true,
    });
    helper.on('error', error => console.error(`[voice] ${label} helper failed: ${error.message}`));
    voiceProcesses.push(helper);
    console.log(`[voice] Started ${label} helper.`);
}
function stopVoiceHelpers() {
    for (const helper of voiceProcesses) {
        if (helper.exitCode === null && !helper.killed) helper.kill();
    }
}
if (existsSync(voicePython)) {
    startVoiceHelper('tts/speaker.py', 'Piper TTS');
    if (microphoneEnabled) {
        // Microphone starts muted. The player explicitly enables it with !voice on.
        writeFileSync(path.join(projectRoot, 'stt', 'muted.flag'), 'muted\n');
        startVoiceHelper('stt/listener.py', 'Whisper microphone');
    } else {
        console.log('[voice] Microphone is not enabled; run .\\setup-voice.ps1 -Microphone to install it.');
    }
} else {
    console.log('[voice] Piper is not installed; run .\\setup-voice.ps1 to enable speech output.');
}

const controlFile = path.join(dir, 'console-commands.txt');
let controlOffset = existsSync(controlFile) ? readFileSync(controlFile).length : 0;
const controlTimer = setInterval(() => {
    try {
        if (!existsSync(controlFile)) return;
        const data = readFileSync(controlFile);
        if (data.length < controlOffset) controlOffset = 0;
        const text = data.subarray(controlOffset).toString('utf8');
        const last = text.lastIndexOf('\n');
        if (last < 0) return;
        controlOffset += Buffer.byteLength(text.slice(0, last + 1));
        for (const command of text.slice(0, last).split('\n')) if (command.trim()) child.stdin.write(command.trim() + '\n');
    } catch (error) { console.error('Control bridge:', error.message); }
}, 300);
let morning = false;
let startupOutput = '';
child.stdout.on('data', chunk => {
    process.stdout.write(chunk);
    liveLog?.write(chunk);
    startupOutput = (startupOutput + String(chunk)).slice(-8192);
    if (!morning && /Done \(/.test(startupOutput)) {
        morning = true;
        for (const command of startupCommands({ worldExists, world: values.world, seed: values.seed }))
            child.stdin.write(`${command}\n`);
    }
});
const forward = signal => () => child.kill(signal);
process.on('SIGINT', forward('SIGINT'));
process.on('SIGTERM', forward('SIGTERM'));
child.on('error', e => {
    stopVoiceHelpers();
    mojangCacheWatcher?.stop();
    console.error(e.code === 'ENOENT' ? 'Java 21+ is required: https://adoptium.net/temurin/releases/?version=21' : e.message);
    process.exit(1);
});
child.on('exit', code => { stopVoiceHelpers(); clearInterval(controlTimer); mojangCacheWatcher?.stop(); liveLog?.end(); process.exit(code ?? 0); });
