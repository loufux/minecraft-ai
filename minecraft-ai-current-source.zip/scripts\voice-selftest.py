#!/usr/bin/env python3
"""Validate the voice environment without shell-quoted Python snippets."""
from __future__ import annotations

import argparse
from importlib.metadata import PackageNotFoundError, version


def package_version(name: str) -> str:
    try:
        return version(name)
    except PackageNotFoundError:
        return "not installed"


def main() -> int:
    parser = argparse.ArgumentParser(description="Check installed Minecraft agent voice components")
    parser.add_argument("--microphone", action="store_true", help="also validate Whisper and PyTorch")
    args = parser.parse_args()

    import audioop  # provided by audioop-lts on Python 3.13+
    import numpy
    import sounddevice
    from piper import PiperVoice

    # Touch imported symbols so this is a real import smoke test, not just metadata.
    _ = (audioop, sounddevice, PiperVoice)
    print("TTS imports OK")
    print(f"Python: {__import__('sys').version.split()[0]}")
    print(f"Piper TTS: {package_version('piper-tts')}")
    print(f"NumPy: {numpy.__version__}")
    print(f"SoundDevice: {package_version('sounddevice')}")
    print(f"audioop-lts: {package_version('audioop-lts')}")

    if args.microphone:
        import torch
        import whisper

        _ = whisper
        print("Microphone imports OK")
        print(f"PyTorch: {torch.__version__}")
        print(f"CUDA available: {torch.cuda.is_available()}")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
