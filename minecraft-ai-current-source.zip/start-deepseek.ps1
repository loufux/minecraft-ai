﻿[CmdletBinding()]
param(
    [string]$Mode = '',
    [string]$PlayerName = 'loufux'
)

$ErrorActionPreference = 'Stop'
& (Join-Path $PSScriptRoot 'scripts\start-local-model-agent.ps1') -AgentName 'DeepSeek' -Mode $Mode -PlayerName $PlayerName
exit $LASTEXITCODE
