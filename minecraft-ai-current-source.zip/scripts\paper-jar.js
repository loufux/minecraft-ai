import path from 'node:path';

// Pin the exact Paper build requested by this project. Each mode stores its
// own copy inside its server folder; the unified launcher synchronizes both.
export const PINNED_PAPER_BUILDS = Object.freeze({ '1.21.6': 48 });

export function getPaperJarFilename(version) {
    const build = PINNED_PAPER_BUILDS[version];
    return build === undefined
        ? `paper-${version}.jar`
        : `paper-${version}-${build}.jar`;
}

export function getPaperBuildApiUrl(version) {
    const base = `https://fill.papermc.io/v3/projects/paper/versions/${version}/builds`;
    const build = PINNED_PAPER_BUILDS[version];
    return build === undefined ? base : `${base}/${build}`;
}

export function resolveServerPaperJar({ projectRoot, version, serverDir = 'server', explicitPath, envPath }) {
    const configuredPath = explicitPath || envPath;
    if (configuredPath) return path.resolve(projectRoot, configuredPath);
    return path.resolve(projectRoot, serverDir, getPaperJarFilename(version));
}

export function selectPaperBuild(buildResponse, version) {
    const pinnedBuild = PINNED_PAPER_BUILDS[version];
    if (pinnedBuild !== undefined) {
        // Fill API returns one object from /builds/{build}; accept an array too
        // for compatibility with cached metadata from older launcher versions.
        const match = Array.isArray(buildResponse)
            ? buildResponse.find(build => Number(build.id ?? build.build ?? build.number) === pinnedBuild)
            : buildResponse;
        if (!match || Number(match.id ?? match.build ?? match.number ?? pinnedBuild) !== pinnedBuild) {
            throw new Error(`Paper ${version} build ${pinnedBuild} was not found; refusing to silently use a different build.`);
        }
        return match;
    }

    if (!Array.isArray(buildResponse)) throw new Error(`Unexpected Paper build metadata for Minecraft ${version}.`);
    const stable = buildResponse.find(build => build.channel === 'STABLE');
    const selected = stable ?? buildResponse[0];
    if (!selected) throw new Error(`No Paper builds are available for Minecraft ${version}.`);
    return selected;
}
