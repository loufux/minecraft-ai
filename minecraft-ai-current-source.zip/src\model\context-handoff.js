const DEFAULT_MAX_CHARS = 6000;
const DEFAULT_ENTRY_CHARS = 1200;

export function appendHandoff(previous, entry, { maxChars = DEFAULT_MAX_CHARS, entryChars = DEFAULT_ENTRY_CHARS } = {}) {
    const oldText = typeof previous === 'string' ? previous.trim() : '';
    const newText = String(entry ?? '').replace(/\s+/g, ' ').trim();
    if (!newText) return oldText.slice(-maxChars);
    const clipped = newText.length > entryChars ? `${newText.slice(0, entryChars - 1)}…` : newText;
    const combined = [oldText, clipped].filter(Boolean).join('\n');
    return combined.length > maxChars ? combined.slice(-maxChars) : combined;
}

export function handoffPrompt(summary, label = 'Previous-session handoff') {
    const text = typeof summary === 'string' ? summary.trim() : '';
    if (!text) return '';
    return `${label} (historical; the fresh Minecraft observation and shared team plan take precedence):\n${text}`;
}

export function compactTranscript(turns, { maxChars = 18000, perMessageChars = 1800 } = {}) {
    const lines = [];
    for (let i = 0; i < (turns ?? []).length; i++) {
        const turn = turns[i];
        lines.push(`--- Older cycle ${i + 1} ---`);
        for (const message of Array.isArray(turn) ? turn : []) {
            const role = String(message?.role ?? 'unknown');
            let body = '';
            if (typeof message?.content === 'string') body = message.content;
            else if (Array.isArray(message?.content)) {
                body = message.content
                    .filter(part => part?.type === 'text' && typeof part.text === 'string')
                    .map(part => part.text)
                    .join('\n');
            }
            if (message?.tool_calls?.length) {
                const calls = message.tool_calls.map(call => ({
                    name: call?.function?.name,
                    arguments: String(call?.function?.arguments ?? '').slice(0, 500),
                }));
                body += `${body ? '\n' : ''}Tool calls: ${JSON.stringify(calls)}`;
            }
            body = String(body ?? '').replace(/\s+/g, ' ').trim();
            if (body) lines.push(`${role}: ${body.slice(0, perMessageChars)}`);
        }
    }
    const transcript = lines.join('\n');
    return transcript.length > maxChars ? transcript.slice(-maxChars) : transcript;
}
