"""Start LM Studio's local API and ensure the Minecraft team models are loaded."""
from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
import time
import urllib.request
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parent.parent
CONFIG_PATH = ROOT / "config" / "lmstudio-team.json"


def read_config() -> dict[str, Any]:
    if not CONFIG_PATH.is_file():
        raise RuntimeError(f"Missing {CONFIG_PATH}. Run setup-lmstudio-minecraft-team.py first.")
    data = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
    if not isinstance(data.get("agents"), dict) or not data["agents"]:
        raise RuntimeError("config/lmstudio-team.json has no agents mapping")
    return data


def write_config(data: dict[str, Any]) -> None:
    CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)
    temp = CONFIG_PATH.with_suffix(".json.tmp")
    temp.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    temp.replace(CONFIG_PATH)


def server_root(config: dict[str, Any]) -> str:
    return str(config.get("serverUrl") or "http://127.0.0.1:1234").rstrip("/")


def auth_headers() -> dict[str, str]:
    headers = {"Accept": "application/json"}
    token = os.environ.get("LM_STUDIO_API_TOKEN", "").strip()
    if token:
        headers["Authorization"] = f"Bearer {token}"
    return headers


def http_json(url: str, body: dict[str, Any] | None = None, timeout: float = 4.0) -> dict[str, Any]:
    headers = auth_headers()
    method = "GET"
    data = None
    if body is not None:
        method = "POST"
        headers["Content-Type"] = "application/json"
        data = json.dumps(body).encode("utf-8")
    request = urllib.request.Request(url, data=data, headers=headers, method=method)
    with urllib.request.urlopen(request, timeout=timeout) as response:
        raw = response.read().decode("utf-8", "replace")
    parsed = json.loads(raw or "{}")
    if not isinstance(parsed, dict):
        raise RuntimeError(f"Unexpected JSON response from {url}")
    return parsed


def find_lms_command() -> tuple[str, bool] | None:
    for name in ("lms", "lms.exe", "lms.cmd", "lms.bat"):
        found = shutil.which(name)
        if found:
            return found, found.lower().endswith((".cmd", ".bat"))
    return None


def run_lms(args: list[str], timeout: float = 45.0) -> subprocess.CompletedProcess[str]:
    command = find_lms_command()
    if not command:
        raise RuntimeError(
            "LM Studio CLI 'lms' was not found. In LM Studio open Settings → Integrations → Install lms CLI, "
            "then reopen PowerShell."
        )
    executable, is_script = command
    if is_script:
        command_line = subprocess.list2cmdline([executable, *args])
        return subprocess.run([os.environ.get("COMSPEC", "cmd.exe"), "/d", "/s", "/c", command_line],
                              cwd=ROOT, text=True, capture_output=True, timeout=timeout, check=False)
    return subprocess.run([executable, *args], cwd=ROOT, text=True, capture_output=True, timeout=timeout, check=False)


def get_available_models(config: dict[str, Any]) -> list[dict[str, Any]]:
    payload = http_json(server_root(config) + "/api/v1/models")
    models = payload.get("models", [])
    return [model for model in models if isinstance(model, dict)] if isinstance(models, list) else []


def ensure_server(config: dict[str, Any]) -> None:
    url = server_root(config) + "/api/v1/models"
    try:
        http_json(url, timeout=2.5)
        return
    except Exception:
        pass
    print("[LM Studio] Local API is not responding; trying `lms server start`...")
    result = run_lms(["server", "start"], timeout=45)
    if result.stdout.strip(): print(result.stdout.strip()[-1200:])
    if result.stderr.strip(): print(result.stderr.strip()[-1200:])
    deadline = time.monotonic() + 60
    last_error = "not ready"
    while time.monotonic() < deadline:
        try:
            http_json(url, timeout=2.5)
            print("[LM Studio] API is ready.")
            return
        except Exception as error:
            last_error = str(error)
            time.sleep(1.5)
    raise RuntimeError(f"LM Studio API did not start at {server_root(config)} ({last_error}). Open LM Studio → Developer → Start Server.")


def _find_model_entry(models: list[dict[str, Any]], spec: dict[str, Any]) -> dict[str, Any] | None:
    key = str(spec.get("lmstudioKey") or spec.get("model") or "").strip().lower()
    filename = str(spec.get("file") or "").strip().lower()
    stem = Path(filename).stem.lower() if filename else ""
    for model in models:
        haystack = " ".join(str(model.get(k, "")) for k in ("key", "path", "repo", "publisher", "display_name", "name")).lower()
        if key and key in haystack:
            return model
        if stem and (stem in haystack or stem.replace("_", "-") in haystack):
            return model
    return None


def ensure_models_loaded(config: dict[str, Any], verbose: bool = True) -> tuple[bool, str]:
    try:
        ensure_server(config)
        models = get_available_models(config)
        changed = False
        for agent_name, spec in config["agents"].items():
            if not isinstance(spec, dict):
                return False, f"Invalid model configuration for {agent_name}."
            model_info = _find_model_entry(models, spec)
            if not model_info:
                return False, f"Model '{spec.get('file') or spec.get('lmstudioKey')}' for {agent_name} is not imported into LM Studio. Re-run the setup script."
            key = str(model_info.get("key") or spec.get("lmstudioKey") or spec.get("model") or "").strip()
            if key and spec.get("lmstudioKey") != key:
                spec["lmstudioKey"] = key
                changed = True
            loaded = model_info.get("loaded_instances") or []
            if not loaded:
                context_length = int(config.get("contextLength", 4096))
                if verbose: print(f"[LM Studio] Loading {agent_name}: {key} (context {context_length})...")
                body = {
                    "model": key,
                    "context_length": context_length,
                    "offload_kv_cache_to_gpu": bool(config.get("offloadKvCacheToGpu", True)),
                    "flash_attention": bool(config.get("flashAttention", True)),
                    "eval_batch_size": int(config.get("evalBatchSize", 256)),
                    "echo_load_config": True,
                }
                try:
                    result = http_json(server_root(config) + "/api/v1/models/load", body, timeout=300)
                except Exception as error:
                    if context_length > 2048:
                        if verbose: print(f"[LM Studio] Load at {context_length} failed; retrying at 2048: {error}")
                        body["context_length"] = 2048
                        result = http_json(server_root(config) + "/api/v1/models/load", body, timeout=300)
                        config["contextLength"] = 2048
                        changed = True
                    else:
                        raise
                if verbose: print(f"[LM Studio] Load response for {agent_name}: {json.dumps(result, ensure_ascii=False)[:500]}")
            elif verbose:
                print(f"[LM Studio] {agent_name}: already loaded ({key})")

        # Refresh after loading. In LM Studio, /v1/models is authoritative for the IDs
        # accepted by the OpenAI-compatible Chat Completions endpoint.
        models_payload = http_json(str(config.get("baseUrl") or (server_root(config) + "/v1")).rstrip("/") + "/models")
        openai_models = [item for item in models_payload.get("data", []) if isinstance(item, dict)]
        openai_ids = [str(item.get("id", "")) for item in openai_models]
        for agent_name, spec in config["agents"].items():
            key = str(spec.get("lmstudioKey", ""))
            current_model = str(spec.get("model", ""))
            if current_model and current_model in openai_ids:
                continue
            matches = [model_id for model_id in openai_ids if key and (model_id == key or key in model_id or model_id in key)]
            if not matches:
                file_stem = Path(str(spec.get("file", ""))).stem.lower()
                matches = [model_id for model_id in openai_ids if file_stem and file_stem in model_id.lower()]
            if not matches:
                return False, f"Model {agent_name} loaded but no matching id was listed by {config.get('baseUrl', 'LM Studio /v1')}/models. Available IDs: {', '.join(openai_ids) or '(none)'}"
            spec["model"] = matches[0]
            changed = True
        if changed:
            write_config(config)
        if verbose:
            print("[LM Studio] All three models are loaded and visible to the agents.")
        return True, "ready"
    except Exception as error:
        return False, str(error)


def main() -> int:
    mode = sys.argv[1].lower() if len(sys.argv) > 1 else "ensure"
    try:
        config = read_config()
        ok, message = ensure_models_loaded(config, verbose=True)
        if not ok:
            print(f"[LM Studio] ERROR: {message}", file=sys.stderr)
            return 1
        print("[LM Studio] Ready.")
        return 0
    except Exception as error:
        print(f"[LM Studio] ERROR: {error}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
