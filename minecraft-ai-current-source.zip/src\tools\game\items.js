import { abortError, failWith } from './failures.js';
import { tossPitchFor } from './guards.js';
import { inventory } from './observation.js';
import { requireFunction, untilAbort } from './runtime.js';
import { coords, count, integer, name, number, text } from './schema.js';
import { describeInventoryItem, findInventoryStacks, matchesItemSelector, summarizeCraftingRecipes, useInventoryItem } from '../../mods/item-support.js';

export function createItems(ctx) {
    const {
        add,
        blockAt,
        body,
        bot,
        call,
        invCount,
        leaveBed,
        pathfinderModule,
        skills,
        sleepAbortable,
        withDeadline,
    } = ctx;
    add('collect_drops', 'Pick up a nearby visible dropped item by walking safely to it. Returns inventory changes; it cannot recover items over the void.',
        { id: integer(0, Number.MAX_SAFE_INTEGER) },
        async (a, { bot: active, signal }) => {
            const drop = active.entities?.[a.id];
            if (!drop || drop.name !== 'item' || !drop.position) throw failWith('not_found', 'That dropped item is no longer visible.', {});
            if (!ctx.perception.isEntityVisible(active, drop, 16)) throw failWith('not_found', 'Drop is not visible or is too far away.', {});
            const before = Object.fromEntries(active.inventory.items().map(i => [i.name, active.inventory.items().filter(x => x.name === i.name).reduce((n, x) => n + x.count, 0)]));
            const { Movements, goals } = await pathfinderModule();
            active.pathfinder.setMovements(new Movements(active));
            const p = drop.position;
            await withDeadline(active, untilAbort(active.pathfinder.goto(new goals.GoalNear(p.x, p.y, p.z, 0.5)), signal), 12000);
            await sleepAbortable(500, signal);
            const after = active.inventory.items().reduce((o, i) => (o[i.name] = (o[i.name] ?? 0) + i.count, o), {});
            return { inventoryDelta: Object.fromEntries(Object.keys(after).map(n => [n, after[n] - (before[n] ?? 0)]).filter(([, n]) => n > 0)), stillVisible: !!active.entities?.[a.id] };
        }, { ...body, required: ['id'] });
    add('inventory', 'Inspect your own inventory and equipped items. Modded item registry IDs and display names are shown when the client exposes them.', {}, () => inventory(bot));
    add(
        'mod_inventory',
        'Inspect inventory items with extra mod-related metadata: namespaced resource IDs, display names, item type IDs, NBT or components. This only shows data actually exposed to this client.',
        {},
        (_a, { bot: active }) => ({
            items: active.inventory.items().map(stack => describeInventoryItem(active, stack, { includeData: true })),
            heldItem: describeInventoryItem(active, active.heldItem, { includeData: true }),
        }),
    );
    add(
        'inspect_item',
        'Inspect a specific item in your inventory by item name, namespaced ID (namespace:item), or exact custom display name. Includes bounded NBT/component metadata when available.',
        { item: text(128) },
        (a, { bot: active }) => {
            const matches = findInventoryStacks(active, a.item);
            if (!matches.length) throw failWith('missing_item', `No inventory item matches "${a.item}".`, {});
            return { selector: a.item, matches: matches.map(stack => describeInventoryItem(active, stack, { includeData: true })) };
        },
    );
    add(
        'mod_recipes',
        'Inspect standard crafting recipes exposed by the connected client for an item, including modded recipes when their item and recipe registry are available. Machine, fluid and multiblock recipes may need a dedicated adapter.',
        { item: name },
        (a, { bot: active }) => summarizeCraftingRecipes(active, a.item),
    );
    add(
        'interact_block',
        'Use a visible block within ordinary reach, such as a lever, button or workbench (for doors and gates prefer door / go_through_door, which know whether it is open).',
        coords,
        call('interact', a => [a.x, a.y, a.z]),
        body,
    );
    add(
        'interact_entity',
        'Right-click a visible entity within ordinary reach.',
        { id: integer(0, Number.MAX_SAFE_INTEGER) },
        call('interactEntity', a => [a.id]),
        body,
    );
    add(
        'equip',
        'Equip an item you possess (hand empties your hand). No automatic armor management.',
        { item: text(128) },
        call('equip', a => [a.item]),
        body,
    );
    add(
        'eat',
        'Eat or drink one named inventory item.',
        { item: name },
        (a, { bot: active, signal }) => untilAbort(requireFunction(skills, 'consume')(active, a.item), signal),
        body,
    );
    add(
        'use_item',
        'Hold and release the currently selected item for a finite duration.',
        { seconds: number(0.05, 5) },
        call('useItem', a => [a.seconds]),
        body,
    );
    add(
        'use_inventory_item',
        'Select a matching item from inventory, equip it, and send a right-click item-use interaction. Useful for modded consumables, roulette tokens, abilities and special items. The tool confirms the interaction packet, not that a mod effect succeeded; inspect the world/player state afterward.',
        { item: text(128), seconds: number(0.05, 5), off_hand: { type: 'boolean' } },
        (a, { bot: active, signal }) => useInventoryItem(active, a.item, a.seconds ?? 0.2, signal, { offHand: a.off_hand === true }),
        { ...body, required: ['item'] },
    );
    add(
        'select_hotbar',
        'Select one of your nine hotbar slots.',
        { slot: integer(0, 8) },
        call('selectHotbar', a => [a.slot]),
        body,
    );
    add(
        'drop_item',
        'Drop items. Without `to`: tosses them a little in front of you and steps back so you do not pick them straight up again. With `to` (another agent or player name): walks next to them, tosses the items at them, and reports whether the items were picked up. Items can be picked up by anyone standing nearby.',
        { item: name, count, to: { type: 'string', minLength: 1, maxLength: 32 } },
        async (a, { bot: active, signal }) => {
            const have = invCount(active, a.item);
            if (!have) throw failWith('missing_item', `You carry no ${a.item}.`, {});
            const n = Math.min(a.count ?? have, have);
            let target = null;
            if (a.to) {
                const want = a.to.toLowerCase();
                const pl = Object.values(active.players ?? {}).find(
                    p => p?.username && p.username.toLowerCase() === want,
                );
                if (pl?.username === active.username)
                    throw failWith('validation', 'You cannot give items to yourself.', {});
                target = pl?.entity ?? null;
                if (!target)
                    throw failWith(
                        'not_found',
                        `${a.to} is not within view range. Ask them where they are, go there, then try again.`,
                        {},
                    );
                if (active.entity.position.distanceTo(target.position) > 1.8) {
                    const { Movements, goals } = await pathfinderModule();
                    const onAbort = () => {
                        try {
                            active.pathfinder.setGoal(null);
                            active.pathfinder.stop();
                        } catch {}
                    };
                    signal?.addEventListener('abort', onAbort, { once: true });
                    try {
                        active.pathfinder.setMovements(new Movements(active));
                        await withDeadline(
                            active,
                            active.pathfinder.goto(
                                new goals.GoalNear(target.position.x, target.position.y, target.position.z, 1),
                            ),
                            30000,
                        );
                    } catch (error) {
                        if (signal?.aborted) throw signal.reason ?? abortError('Tool cancelled');
                        throw failWith(
                            'no_path',
                            `Could not walk next to ${a.to} (${String(error?.message ?? error).slice(0, 60)}). Nothing was dropped.`,
                            {},
                        );
                    } finally {
                        signal?.removeEventListener('abort', onAbort);
                    }
                    target = active.players?.[pl.username]?.entity ?? target;
                }
                const dx = target.position.x - active.entity.position.x,
                    dz = target.position.z - active.entity.position.z;
                const dy = target.position.y - active.entity.position.y,
                    dist = Math.hypot(dx, dz);
                const landAt = dy > 0.5 ? Math.max(dist, 0.9) : Math.min(Math.max(dist + 0.5, 1.7), 4);
                try {
                    await active.look(
                        Math.atan2(-dx, -dz),
                        tossPitchFor(landAt, dy > 0.5 ? dy : Math.min(dy, 0)),
                        true,
                    );
                } catch {}
            } else {
                const yaw = active.entity.yaw;
                try {
                    await active.look(yaw, -0.35, true);
                } catch {}
            }
            try {
                active.clearControlStates();
            } catch {}
            await sleepAbortable(300, signal);
            const dropAt = active.entity.position.clone?.() ?? active.entity.position;
            let tossed = 0;
            for (const it of active.inventory.items().filter(i => matchesItemSelector(active, i, a.item))) {
                if (tossed >= n) break;
                const c = Math.min(n - tossed, it.count);
                await untilAbort(active.toss(it.type, null, c), signal);
                tossed += c;
            }
            const t0 = Date.now();
            try {
                active.setControlState('back', true);
                await sleepAbortable(600, signal);
            } finally {
                try {
                    active.setControlState('back', false);
                } catch {}
            }
            const movedAway =
                Math.round(Math.hypot(active.entity.position.x - dropAt.x, active.entity.position.z - dropAt.z) * 10) /
                10;
            const ours = () => Math.max(0, invCount(active, a.item) - (have - tossed));
            const onGround = () =>
                Object.values(active.entities ?? {}).filter(
                    e =>
                        e?.name === 'item' &&
                        e.position?.distanceTo?.(dropAt) <= 6 &&
                        matchesItemSelector(active, e.getDroppedItem?.(), a.item),
                ).length;
            while (Date.now() - t0 < 4000 && !signal?.aborted) {
                if (ours() > 0 || (Date.now() - t0 > 2500 && !onGround())) break;
                await sleepAbortable(250, signal);
            }
            const back = ours(),
                lying = onGround();
            const out = { dropped: tossed, item: a.item };
            if (a.to) out.to = a.to;
            if (back) out.pickedBackUp = back;
            if (a.to) {
                const them = active.players?.[target?.username ?? '']?.entity ?? target;
                const gap = them ? Math.round(them.position.distanceTo(active.entity.position) * 10) / 10 : null;
                out.status = back
                    ? `${back} came back to you: you were still within reach of the items when they became collectable (you only got ${movedAway} blocks away; ${a.to} was ${gap} blocks from you). Whoever is in reach first gets them. Try from a spot with room to step back, or drop them without \`to\` and walk off so ${a.to} can collect them.`
                    : lying
                      ? `${tossed} still on the ground near ${a.to}; they can walk over it to pick it up`
                      : `picked up (${a.to} was the nearest player)`;
            } else if (back) out.note = `${back} landed back in your inventory`;
            return out;
        },
        { ...body, required: ['item'] },
    );
    add(
        'sleep',
        'Sleep in a visible bed within reach. Ordinary server sleep rules still apply.',
        coords,
        async (a, { bot: active, signal }) => {
            if (active.isSleeping)
                return {
                    sleeping: true,
                    note: 'Already in bed. Night passes once enough of the players online are asleep. Any other action gets you out of bed first.',
                };
            await untilAbort(active.sleep(blockAt(active, a, 3)), signal);
            return { sleeping: active.isSleeping };
        },
        body,
    );
    add(
        'wake',
        'Get out of bed.',
        {},
        async () => {
            if (!bot.isSleeping) return { awake: true, note: 'already awake' };
            await leaveBed(bot);
            return { awake: !bot.isSleeping };
        },
        body,
    );
}
