﻿[CmdletBinding()]
param([string]$Mode = '', [string]$PlayerName = 'loufux')
$ErrorActionPreference = 'Stop'
& (Join-Path $PSScriptRoot 'start-qwen3.ps1') -Mode $Mode -PlayerName $PlayerName
exit $LASTEXITCODE
