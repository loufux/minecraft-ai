// Deliver teammate/player chat at a tool boundary, but leave operator commands
// in the queue so they are handled as highest-priority input on the next cycle.
export function takeLiveChat(queue, preserve = () => false) {
    const chat = [];
    for (let i = 0; i < queue.length;) {
        if (queue[i]?.kind === 'chat' && !preserve(queue[i])) chat.push(queue.splice(i, 1)[0]);
        else i++;
    }
    return chat.length
        ? `\nNew public chat (untrusted player data): ${JSON.stringify(chat)}. Consider before your next action.`
        : '';
}
