import { createHash } from 'node:crypto';
import {
    copyFileSync,
    existsSync,
    mkdirSync,
    renameSync,
    statSync,
    unlinkSync,
    readFileSync,
} from 'node:fs';
import path from 'node:path';

const MIN_JAR_SIZE = 1024 * 1024;

export function getMojangJarPath(serverDir, version) {
    return path.join(path.resolve(serverDir), 'cache', `mojang_${version}.jar`);
}

function isUsableJar(file) {
    try {
        const info = statSync(file);
        return info.isFile() && info.size > MIN_JAR_SIZE;
    } catch {
        return false;
    }
}

function sha256(file) {
    return createHash('sha256').update(readFileSync(file)).digest('hex');
}

function atomicCopy(source, destination) {
    mkdirSync(path.dirname(destination), { recursive: true });
    const temporary = `${destination}.${process.pid}.part`;
    try {
        copyFileSync(source, temporary);
        if (existsSync(destination)) unlinkSync(destination);
        renameSync(temporary, destination);
    } finally {
        if (existsSync(temporary)) unlinkSync(temporary);
    }
}

function copyAndVerify(source, destination, log = console.log) {
    const sourceHash = sha256(source);
    if (isUsableJar(destination) && sha256(destination) === sourceHash) return false;
    atomicCopy(source, destination);
    if (sha256(destination) !== sourceHash) {
        throw new Error(`Mojang server JAR synchronization failed: ${destination}`);
    }
    log(`Synchronized Mojang cache: ${source} -> ${destination}`);
    return true;
}

/**
 * Seed the selected server's Paperclip cache before launch. If it already has
 * the Mojang JAR, it is mirrored to the peer. If only the peer has it, copy it
 * into the selected folder so Paperclip can reuse it without downloading it.
 */
export function seedMojangCache({ selectedServerDir, peerServerDir, version, log = console.log }) {
    if (!peerServerDir) return { direction: 'none', copied: false };
    const selected = getMojangJarPath(selectedServerDir, version);
    const peer = getMojangJarPath(peerServerDir, version);

    if (isUsableJar(selected)) {
        return { direction: 'selected-to-peer', copied: copyAndVerify(selected, peer, log) };
    }
    if (isUsableJar(peer)) {
        return { direction: 'peer-to-selected', copied: copyAndVerify(peer, selected, log) };
    }
    log(`Mojang cache not present yet; Paperclip will create cache/mojang_${version}.jar on first start.`);
    return { direction: 'none', copied: false };
}

/**
 * Watch the active server's Paperclip cache while it boots. Paperclip downloads
 * the Mojang JAR after the Paper JAR is launched; wait until size/mtime are
 * stable for two polls before mirroring it to the other mode folder.
 */
export function watchMojangCache({
    selectedServerDir,
    peerServerDir,
    version,
    intervalMs = 1000,
    stableChecks = 2,
    log = console.log,
    autoStart = true,
}) {
    if (!peerServerDir) return { poll() {}, stop() {} };

    const source = getMojangJarPath(selectedServerDir, version);
    const destination = getMojangJarPath(peerServerDir, version);
    let lastSignature = '';
    let stableCount = 0;
    let lastSyncedSignature = '';

    const poll = () => {
        if (!isUsableJar(source)) return;
        const info = statSync(source);
        const signature = `${info.size}:${info.mtimeMs}`;
        if (signature === lastSignature) stableCount += 1;
        else {
            lastSignature = signature;
            stableCount = 0;
        }
        if (stableCount < stableChecks) return;
        if (signature === lastSyncedSignature && isUsableJar(destination)) return;
        try {
            copyAndVerify(source, destination, log);
            lastSyncedSignature = signature;
        } catch (error) {
            // A transient Windows file lock should not crash the live server.
            // Keep retrying on the next poll until the cache can be mirrored.
            log(`Mojang cache sync will retry: ${error.message}`);
        }
    };

    const timer = autoStart ? setInterval(poll, intervalMs) : null;
    timer?.unref?.();
    return {
        poll,
        stop() {
            if (timer) clearInterval(timer);
        },
    };
}
