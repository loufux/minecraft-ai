﻿function Get-AgentModeConfig {
    [CmdletBinding()]
    param(
        [string]$RequestedMode = '',
        [string]$PlayerName = 'loufux'
    )

    $selectedMode = ''
    if (-not [string]::IsNullOrWhiteSpace($RequestedMode)) {
        switch ($RequestedMode.Trim().ToLowerInvariant()) {
            { $_ -in @('vanilla', 'v', '1') } { $selectedMode = 'vanilla'; break }
            { $_ -in @('skyblock', 's', '2') } { $selectedMode = 'skyblock'; break }
            default { throw "Unknown mode '$RequestedMode'. Use -Mode Vanilla or -Mode Skyblock." }
        }
    } else {
        Write-Host ''
        Write-Host '========================================' -ForegroundColor Cyan
        Write-Host '          MINECRAFT AI AGENTS' -ForegroundColor Cyan
        Write-Host '========================================' -ForegroundColor Cyan
        Write-Host '  1. Vanilla Survival — обычный мир' -ForegroundColor Green
        Write-Host '  2. Skyblock — остров' -ForegroundColor Yellow
        Write-Host '  Q. Выход' -ForegroundColor DarkGray
        Write-Host ''

        while ($true) {
            $choice = (Read-Host 'Выбери режим [1/2, Q — выход]').Trim().ToUpperInvariant()
            switch ($choice) {
                { $_ -in @('1', 'V', 'VANILLA') } { $selectedMode = 'vanilla'; break }
                { $_ -in @('2', 'S', 'SKYBLOCK') } { $selectedMode = 'skyblock'; break }
                { $_ -in @('Q', 'EXIT') } { $selectedMode = 'exit'; break }
                default { Write-Host 'Введи 1 (Vanilla), 2 (Skyblock) или Q (выход).' -ForegroundColor Yellow }
            }
            if ($selectedMode) { break }
        }
    }

    if ($selectedMode -eq 'exit') { return $null }

    if ($selectedMode -eq 'vanilla') {
        $config = [pscustomobject]@{
            Mode = 'vanilla'
            Scenario = 'vanilla'
            StateDir = '.agent-state-vanilla'
            ServerDir = 'vanilla-server'
            PeerDir = 'skyblock-server'
            World = 'normal'
            Objective = 'Cooperate as one team in ordinary Minecraft Java survival. Start from the naturally generated Overworld spawn, gather resources, build a safe base, progress through the Nether, find a stronghold, enter the End and defeat the Ender Dragon. Verify important discoveries and the final victory in the actual world.'
        }
    } else {
        $config = [pscustomobject]@{
            Mode = 'skyblock'
            Scenario = 'skyblock'
            StateDir = '.agent-state'
            ServerDir = 'skyblock-server'
            PeerDir = 'vanilla-server'
            World = 'void'
            Objective = 'Cooperate with ChatGPT, Claude and DeepSeek in Skyblock. Together put 1 diamond in the starter chest at (-2,65,-4). Mine cobblestone from the existing generator, reach the sand island, build a house and reach the Nether along the way.'
        }
    }

    # Keep every launcher and the server launcher on exactly the same mode settings.
    $env:AGENT_SCENARIO = $config.Scenario
    $env:AGENT_STATE_DIR = $config.StateDir
    $env:MINECRAFT_OBJECTIVE = $config.Objective
    $env:MINECRAFT_SERVER_DIR = $config.ServerDir
    $env:MINECRAFT_OPERATOR = $PlayerName
    $env:PYTHONUTF8 = '1'
    if ($config.Mode -eq 'skyblock') {
        $env:SKYBLOCK_PLAYER = $PlayerName
    } else {
        Remove-Item Env:SKYBLOCK_PLAYER -ErrorAction SilentlyContinue
    }

    return $config
}
