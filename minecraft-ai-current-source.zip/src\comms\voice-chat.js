const escapeRegExp = value => String(value).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

// The microphone bridge sends a tellraw system message, not a player chat packet.
// Resolve the configured operator dynamically so Vanilla and Skyblock use the same bridge.
export function parseVoiceChat(
    message,
    position,
    sender,
    player = process.env.MINECRAFT_OPERATOR || process.env.SKYBLOCK_PLAYER || 'loufux',
) {
    if (sender != null || position === 'chat') return null;
    const text = typeof message?.toString === 'function' ? message.toString() : String(message);
    const pattern = new RegExp(`^<${escapeRegExp(player)}> \\(голос\\) (.+)$`, 'u');
    return pattern.exec(text)?.[1] ?? null;
}
