const VANILLA_NAMESPACE = 'minecraft';
const MAX_METADATA_DEPTH = 5;
const MAX_METADATA_KEYS = 32;
const MAX_METADATA_ARRAY = 24;
const MAX_METADATA_STRING = 1200;

const clean = value => String(value ?? '').trim();
const lower = value => clean(value).toLocaleLowerCase('en-US');

export function normalizeResourceId(value) {
    const raw = lower(value);
    if (!raw) return null;
    if (raw.includes(':')) {
        const [namespace, ...rest] = raw.split(':');
        const path = rest.join(':');
        if (!/^[a-z0-9_.-]+$/.test(namespace) || !/^[a-z0-9_./-]+$/.test(path)) return null;
        return `${namespace}:${path}`;
    }
    if (!/^[a-z0-9_./-]+$/.test(raw)) return null;
    return raw;
}

function boundedValue(value, depth = 0, seen = new WeakSet()) {
    if (value == null || typeof value === 'boolean' || typeof value === 'number') return value;
    if (typeof value === 'string') return value.length > MAX_METADATA_STRING ? `${value.slice(0, MAX_METADATA_STRING)}…` : value;
    if (typeof value === 'bigint') return String(value);
    if (Buffer.isBuffer(value) || value instanceof Uint8Array)
        return { type: 'bytes', length: value.length, preview: Buffer.from(value).subarray(0, 32).toString('hex') };
    if (typeof value !== 'object') return String(value);
    if (seen.has(value)) return '[Circular]';
    if (depth >= MAX_METADATA_DEPTH) return '[MaxDepth]';
    seen.add(value);
    try {
        if (Array.isArray(value)) return value.slice(0, MAX_METADATA_ARRAY).map(v => boundedValue(v, depth + 1, seen));
        const out = {};
        for (const [key, entry] of Object.entries(value).slice(0, MAX_METADATA_KEYS))
            out[key] = boundedValue(entry, depth + 1, seen);
        if (Object.keys(value).length > MAX_METADATA_KEYS) out._truncatedKeys = Object.keys(value).length - MAX_METADATA_KEYS;
        return out;
    } finally {
        seen.delete(value);
    }
}

function itemRegistryInfo(bot, stack) {
    const registry = bot?.registry ?? {};
    const byId = Number.isInteger(stack?.type) ? registry.items?.[stack.type] : null;
    if (byId) {
        const key = Object.entries(registry.itemsByName ?? {}).find(([, entry]) => entry?.id === byId.id)?.[0] ?? null;
        return { entry: byId, key };
    }
    const byName = Object.entries(registry.itemsByName ?? {}).find(([key, entry]) =>
        key === stack?.name || entry?.name === stack?.name,
    );
    return byName ? { key: byName[0], entry: byName[1] } : { key: null, entry: null };
}


export function resourceIdForType(bot, type) {
    const entry = bot?.registry?.items?.[type];
    if (!entry) return null;
    const key = Object.entries(bot?.registry?.itemsByName ?? {}).find(([, value]) => value?.id === entry.id)?.[0] ?? null;
    if (key?.includes(':')) return lower(key);
    const name = lower(entry.name);
    if (name.includes(':')) return name;
    return `${lower(entry.namespace || VANILLA_NAMESPACE)}:${name}`;
}

function itemNameCandidates(bot, stack) {
    const { entry, key } = itemRegistryInfo(bot, stack);
    const rawName = clean(stack?.name);
    const entryName = clean(entry?.name);
    const fullName = key?.includes(':')
        ? key
        : entryName.includes(':')
          ? entryName
          : entry?.namespace
            ? `${entry.namespace}:${entryName}`
            : entryName
              ? `${VANILLA_NAMESPACE}:${entryName}`
              : rawName.includes(':')
                ? rawName
                : null;
    return [...new Set([rawName, entryName, key, fullName].filter(Boolean).map(lower))];
}

function findCustomName(value, depth = 0) {
    if (!value || typeof value !== 'object' || depth > 5) return null;
    for (const [key, entry] of Object.entries(value)) {
        if (/^(customname|custom_name|displayname|display_name)$/i.test(key)) {
            if (typeof entry === 'string') return entry;
            if (entry && typeof entry === 'object') {
                const text = entry.text ?? entry.value;
                if (typeof text === 'string') return text;
            }
        }
        if (entry && typeof entry === 'object') {
            const nested = findCustomName(entry, depth + 1);
            if (nested) return nested;
        }
    }
    return null;
}

export function describeInventoryItem(bot, stack, { includeData = false } = {}) {
    if (!stack) return null;
    const { entry } = itemRegistryInfo(bot, stack);
    const names = itemNameCandidates(bot, stack);
    const nbt = stack.nbt ?? stack.components ?? stack.componentMap ?? null;
    const displayName = findCustomName(nbt) || clean(stack.displayName) || null;
    const result = {
        name: stack.name ?? null,
        resourceId: names.find(n => n.includes(':')) ?? null,
        displayName,
        type: Number.isInteger(stack.type) ? stack.type : null,
        count: Number.isFinite(stack.count) ? stack.count : null,
        slot: Number.isInteger(stack.slot) ? stack.slot : null,
        durability: Number.isFinite(stack.durabilityUsed) ? stack.durabilityUsed : null,
        maxDurability: Number.isFinite(stack.maxDurability) ? stack.maxDurability : null,
        registryKnown: Boolean(entry),
    };
    if (includeData && nbt) result.data = boundedValue(nbt);
    return result;
}

export function matchesItemSelector(bot, stack, selector) {
    const rawWanted = lower(selector);
    const wanted = normalizeResourceId(selector);
    if (!rawWanted || !stack) return false;
    const names = itemNameCandidates(bot, stack);
    const displayName = lower(findCustomName(stack.nbt ?? stack.components) || stack.displayName);
    if (wanted?.includes(':')) return names.includes(wanted);
    const pathMatches = wanted ? names.some(n => (n.includes(':') ? n.slice(n.indexOf(':') + 1) : n) === wanted) : false;
    return pathMatches || displayName === rawWanted;
}

export function findInventoryStacks(bot, selector) {
    const items = bot?.inventory?.items?.() ?? [];
    const matches = items.filter(stack => matchesItemSelector(bot, stack, selector));
    const wanted = normalizeResourceId(selector);
    if (matches.length > 1 && !wanted?.includes(':')) {
        const ids = new Set(matches.map(stack => itemNameCandidates(bot, stack).find(n => n.includes(':')) ?? stack.name));
        if (ids.size > 1) {
            const error = new Error(`Item selector "${selector}" is ambiguous. Use a namespaced id such as namespace:item.`);
            error.code = 'AMBIGUOUS_ITEM';
            throw error;
        }
    }
    return matches;
}

export function resolveRegistryItem(bot, selector) {
    const wanted = normalizeResourceId(selector);
    if (!wanted) return null;
    const registry = bot?.registry ?? {};
    const entries = Object.entries(registry.itemsByName ?? {});
    const exact = entries.find(([key, entry]) => {
        const name = lower(entry?.name);
        const namespace = lower(entry?.namespace || VANILLA_NAMESPACE);
        return lower(key) === wanted || name === wanted || `${namespace}:${name}` === wanted;
    });
    if (exact) return exact[1];
    if (wanted.includes(':')) return null;
    const candidates = entries.filter(([, entry]) => lower(entry?.name) === wanted);
    return candidates.length === 1 ? candidates[0][1] : null;
}

export function summarizeCraftingRecipes(bot, selector) {
    const entry = resolveRegistryItem(bot, selector);
    if (!entry || !Number.isSafeInteger(entry.id)) {
        return { item: selector, available: false, reason: 'This item is not present in the client item registry. A mod-specific protocol/server adapter may be required.' };
    }
    const recipes = bot.recipesAll?.(entry.id, null, true) ?? bot.recipesFor?.(entry.id, null, 1, true) ?? [];
    const itemById = id => resourceIdForType(bot, id) ?? `unknown_item_${id}`;
    return {
        item: entry.name,
        resourceId: entry.name.includes(':') ? entry.name : `${entry.namespace || VANILLA_NAMESPACE}:${entry.name}`,
        available: recipes.length > 0,
        recipes: recipes.slice(0, 12).map(recipe => {
            const delta = Array.isArray(recipe.delta) ? recipe.delta : [];
            const ingredients = delta.filter(part => part.count < 0).map(part => ({ item: itemById(part.id), count: -part.count }));
            const output = recipe.result ?? delta.find(part => part.count > 0) ?? null;
            return {
                ingredients,
                result: output ? { item: itemById(output.id ?? entry.id), count: output.count ?? 1 } : { item: entry.name, count: 1 },
                requiresCraftingTable: Boolean(recipe.requiresTable),
            };
        }),
        note: recipes.length ? 'Only recipes exposed by Mineflayer/client registry are listed. Machine, fluid, multiblock and scripted recipes may require a dedicated adapter.' : 'No standard crafting recipe is exposed. This does not prove the mod has no recipe; it may use a machine or custom recipe packet.'
    };
}

export async function useInventoryItem(bot, selector, seconds, signal, { offHand = false } = {}) {
    if (!Number.isFinite(seconds) || seconds < 0.05 || seconds > 5) throw new Error('Use duration must be between 0.05 and 5 seconds.');
    const matches = findInventoryStacks(bot, selector);
    if (!matches.length) throw Object.assign(new Error(`No inventory item matches "${selector}".`), { code: 'MISSING_ITEM' });
    const chosen = matches[0];
    const before = describeInventoryItem(bot, chosen, { includeData: true });
    await bot.equip(chosen, offHand ? 'off-hand' : 'hand');
    if (signal?.aborted) throw signal.reason ?? new Error('Action cancelled');
    try {
        bot.activateItem(offHand);
        const until = Date.now() + seconds * 1000;
        while (Date.now() < until) {
            if (signal?.aborted || bot.interrupt_code) throw signal?.reason ?? new Error('Action cancelled');
            await new Promise(resolve => setTimeout(resolve, Math.min(50, until - Date.now())));
        }
    } finally {
        bot.deactivateItem();
    }
    return {
        used: before,
        hand: offHand ? 'off-hand' : 'main-hand',
        interaction: 'right-click / item activation packet',
        remaining: findInventoryStacks(bot, selector).map(stack => describeInventoryItem(bot, stack)),
        note: 'Mineflayer sent the item-use interaction; a mod-specific effect is only confirmed by observing the resulting game state.'
    };
}
