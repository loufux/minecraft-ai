﻿[CmdletBinding()]
param(
    [string]$Mode = '',
    [string]$PlayerName = 'loufux',
    [string]$Seed = '2024',
    [string]$Memory = '3G',
    [switch]$StartAgents,
    [switch]$ResumeReset
)

$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
. (Join-Path $PSScriptRoot 'scripts\agent-mode.ps1')

$modeConfig = Get-AgentModeConfig -RequestedMode $Mode -PlayerName $PlayerName
if ($null -eq $modeConfig) {
    Write-Host 'Запуск отменён.' -ForegroundColor DarkGray
    return
}

$selectedMode = $modeConfig.Mode

# Paper 1.21.6 is compiled for Java 21 (class-file version 65). Resolve a
# Java 21+ runtime explicitly so an older java.exe earlier on PATH cannot be
# selected accidentally.
function Get-JavaRuntimeInfo {
    param([Parameter(Mandatory = $true)][string]$JavaPath)
    if (-not (Test-Path -LiteralPath $JavaPath -PathType Leaf)) { return $null }

    # java.exe writes its version banner to STDERR. In Windows PowerShell 5.1,
    # merging native STDERR into the pipeline (2>&1) can create a terminating
    # NativeCommandError when $ErrorActionPreference is Stop. Capture both
    # streams through .NET instead, so Java 17 is treated as a candidate to
    # skip rather than as a PowerShell script failure.
    $process = New-Object System.Diagnostics.Process
    $startInfo = New-Object System.Diagnostics.ProcessStartInfo
    $startInfo.FileName = $JavaPath
    $startInfo.Arguments = '-version'
    $startInfo.UseShellExecute = $false
    $startInfo.RedirectStandardOutput = $true
    $startInfo.RedirectStandardError = $true
    $startInfo.CreateNoWindow = $true
    $process.StartInfo = $startInfo

    try {
        if (-not $process.Start()) { return $null }
        $stderr = $process.StandardError.ReadToEnd()
        $stdout = $process.StandardOutput.ReadToEnd()
        $process.WaitForExit()
        $output = (($stderr, $stdout) -join [Environment]::NewLine).Trim()
        if ($process.ExitCode -ne 0) { return $null }
    }
    catch {
        return $null
    }
    finally {
        $process.Dispose()
    }

    $match = [regex]::Match($output, '(?i)version\s+"?(\d+)')
    if (-not $match.Success) {
        $match = [regex]::Match($output, '(?i)openjdk\s+(\d+)')
    }
    if (-not $match.Success) { return $null }
    return [pscustomobject]@{
        Path = (Resolve-Path -LiteralPath $JavaPath).Path
        Major = [int]$match.Groups[1].Value
        VersionOutput = $output
    }
}

$javaCandidates = @()
if ($env:JAVA_HOME) { $javaCandidates += (Join-Path $env:JAVA_HOME 'bin\java.exe') }
$pathJava = Get-Command 'java.exe' -ErrorAction SilentlyContinue
if ($pathJava -and $pathJava.Source) { $javaCandidates += $pathJava.Source }
$whereJava = & where.exe java.exe 2>$null
if ($whereJava) { $javaCandidates += @($whereJava) }

$javaRoots = @()
if ($env:ProgramFiles) {
    $javaRoots += @(
        (Join-Path $env:ProgramFiles 'Eclipse Adoptium'),
        (Join-Path $env:ProgramFiles 'Java'),
        (Join-Path $env:ProgramFiles 'Amazon Corretto'),
        (Join-Path $env:ProgramFiles 'Microsoft'),
        (Join-Path $env:ProgramFiles 'Zulu'),
        (Join-Path $env:ProgramFiles 'BellSoft')
    )
}
if ($env:LOCALAPPDATA) {
    $javaRoots += (Join-Path $env:LOCALAPPDATA 'Programs\Eclipse Adoptium')
}
foreach ($javaRoot in $javaRoots) {
    if (Test-Path -LiteralPath $javaRoot -PathType Container) {
        $javaDirs = Get-ChildItem -LiteralPath $javaRoot -Directory -ErrorAction SilentlyContinue |
            Where-Object { $_.Name -match '(?i)(?:jdk|jre)[-_]?21(?:[.+_-]|$)' }
        foreach ($javaDir in $javaDirs) {
            $javaCandidates += (Join-Path $javaDir.FullName 'bin\java.exe')
        }
    }
}

$javaRuntime = $null
$detectedJava = $null
foreach ($candidate in ($javaCandidates | Where-Object { $_ } | Select-Object -Unique)) {
    $candidateInfo = Get-JavaRuntimeInfo -JavaPath $candidate
    if ($null -eq $candidateInfo) { continue }
    if ($null -eq $detectedJava -or $candidateInfo.Major -gt $detectedJava.Major) {
        $detectedJava = $candidateInfo
    }
    if ($candidateInfo.Major -ge 21) {
        $javaRuntime = $candidateInfo
        break
    }
}

if ($null -eq $javaRuntime) {
    Write-Host ''
    Write-Host 'ERROR: Paper 1.21.6 requires Java 21 or newer.' -ForegroundColor Red
    if ($detectedJava) {
        Write-Host "Detected Java $($detectedJava.Major): $($detectedJava.Path)" -ForegroundColor Yellow
        Write-Host $detectedJava.VersionOutput -ForegroundColor DarkGray
        Write-Host 'Java 17 produces class-file version 61; Paper was compiled as class-file version 65 (Java 21).' -ForegroundColor Yellow
    } else {
        Write-Host 'No usable Java runtime was found.' -ForegroundColor Yellow
    }
    Write-Host 'Install 64-bit Java 21 (Temurin): https://adoptium.net/temurin/releases/?version=21' -ForegroundColor Cyan
    Write-Host 'After installation, reopen PowerShell and run .\start-server.ps1 again.' -ForegroundColor Cyan
    exit 1
}

$javaBin = Split-Path -Parent $javaRuntime.Path
$env:JAVA_EXE = $javaRuntime.Path
$env:JAVA_HOME = Split-Path -Parent $javaBin
$env:PATH = "$javaBin;$env:PATH"
Write-Host "Using Java $($javaRuntime.Major): $($javaRuntime.Path)" -ForegroundColor Green

$version = '1.21.6'
$paperFilename = 'paper-1.21.6-48.jar'
$serverDirName = $modeConfig.ServerDir
$peerDirName = $modeConfig.PeerDir
$serverDir = Join-Path $PSScriptRoot $serverDirName
$peerDir = Join-Path $PSScriptRoot $peerDirName
New-Item -ItemType Directory -Force -Path $serverDir, $peerDir | Out-Null

# Keep one local copy in each mode folder. The selected mode is always the
# source of truth: download there if missing, verify, then mirror to its peer.
$activePaperJar = Join-Path $serverDir $paperFilename
$peerPaperJar = Join-Path $peerDir $paperFilename
$env:PAPER_JAR = $activePaperJar
$env:PAPER_PEER_DIR = $peerDir
$env:MC_MEMORY = $Memory

Write-Host ''
Write-Host "Selected mode: $($selectedMode.ToUpperInvariant())" -ForegroundColor Cyan
Write-Host "Paper location: $activePaperJar" -ForegroundColor DarkGray
Write-Host 'Checking/downloading Paper into the selected mode folder, then synchronizing the other mode folder...' -ForegroundColor Cyan
$ensurePaperScript = Join-Path $PSScriptRoot 'scripts\ensure-paper.js'
& node $ensurePaperScript --version $version --target $activePaperJar --peer $peerPaperJar
if ($LASTEXITCODE -ne 0) {
    throw "Paper preparation failed (exit code $LASTEXITCODE). The server was not started."
}

$controllerPath = Join-Path $PSScriptRoot 'scripts\agent-controller.py'
$controllerArgs = '"' + $controllerPath + '"'
if ($StartAgents) {
    $controllerLog = Join-Path $serverDirName 'live-console.log'
    $controllerOffset = 0
    if (Test-Path $controllerLog) {
        $controllerOffset = (Get-Item $controllerLog).Length
    }
    $controllerArgs += " --start-when-ready --log-start-offset $controllerOffset"
}
Start-Process -FilePath 'python' -ArgumentList $controllerArgs -WorkingDirectory $PSScriptRoot -WindowStyle Hidden

if ($selectedMode -eq 'vanilla') {
    Write-Host 'Starting a normally generated Minecraft survival world (Normal difficulty).' -ForegroundColor Green
    Write-Host "Operator: $PlayerName | Seed: $Seed | RAM: $Memory"
    Write-Host 'Connect with Minecraft Java 1.21.6 at localhost:25565.'
    Write-Host 'Type stop in this window to shut down the server.'
    & node scripts/dev-server.js --world normal --dir $serverDirName --mc-version $version --memory $Memory --seed $Seed
} else {
    Write-Host 'Starting the Skyblock island server.' -ForegroundColor Yellow
    Write-Host "Operator: $PlayerName | RAM: $Memory"
    Write-Host 'Type stop in this window to shut down the server.'
    $supervisorArgs = @('scripts/skyblock-supervisor.py')
    if ($ResumeReset) { $supervisorArgs += '--resume-reset' }
    & python @supervisorArgs
}

if ($LASTEXITCODE -ne 0) {
    exit $LASTEXITCODE
}
