// General Nether portal instructions for naturally generated survival worlds.
export const VANILLA_PORTAL_SKILL = `NETHER PORTAL — ordinary survival-world procedure. Do not assume a portal, obsidian cache, flint, iron or prepared building site already exists. Inspect inventories and the real site first; tell the team what is missing.

RESOURCES: A minimal upright portal uses 10 obsidian in a 4-wide by 5-high outer rectangle; the four corners may be empty or made from ordinary solid blocks. Mine obsidian only with a diamond or netherite pickaxe if collecting it normally. A safe lava-and-water casting method may be used only when the tools and placement sequence are understood; never improvise near an exposed lava pool. Obtain flint and steel (one flint and one iron ingot) or a fire charge to ignite the portal. Keep spare blocks, food and a safe return route.

PLAN: Choose a supported, non-flammable site with room to stand and access both sides. Let (X,Y,Z) be the lower-left OUTER corner, with X increasing to the right and all cells sharing Z. The required frame is:
  y=Y+4  [ ][O][O][ ]
  y=Y+3  [O][ ][ ][O]
  y=Y+2  [O][ ][ ][O]
  y=Y+1  [O][ ][ ][O]
  y=Y    [ ][O][O][ ]
O = obsidian. The inner opening is 2 blocks wide by 3 high. The 10 required obsidian positions are bottom (X+1,Y,Z),(X+2,Y,Z); sides (X,Y+1..Y+3,Z),(X+3,Y+1..Y+3,Z); top (X+1,Y+4,Z),(X+2,Y+4,Z). Coordinates are a formula, not a suggested build location: choose a site from current observations and calculate the actual positions. Inspect every target and support before placement.

BUILD AND VERIFY: Make a safe solid floor first. Place the ten obsidian blocks and inspect the completed rectangle from the side. The six interior cells must be air; remove obstructions only when safe. Do not place obsidian inside the opening or build the frame flat on the ground. If any block is misplaced, do not break obsidian without a diamond/netherite pickaxe; adapt the frame safely instead. Light the inside bottom of the frame with flint and steel or a fire charge. Confirm that purple nether_portal blocks actually appeared before saying it works.

ENTER: Record the portal's Overworld coordinates and tell teammates. One explorer enters first, checks the destination and portal surroundings, and reports a safe route. Nether portals can link to unexpected locations; do not assume the destination is safe. Keep the return route and supplies protected.`;
